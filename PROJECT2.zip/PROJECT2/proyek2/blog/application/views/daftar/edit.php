<h1>              12345   AKU  SAYANG KAMU</h1>
<h2>          12345       KAMU SAYANG DIA</h2>