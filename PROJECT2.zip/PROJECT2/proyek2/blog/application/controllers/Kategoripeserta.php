<?php
class Kategoripeserta extends CI_Controller{
    public function index(){
     // akses model

     $this->load->model('kategoripeserta_model');
     $kategori_peserta = $this->kategoripeserta_model->getAll();
     $data['kategori_peserta'] = $kategori_peserta;
        
        $this->load->view('layout/header');
        $this->load->view('layout/side');
        $this->load->view('kategori_peserta/index', $data);
        $this->load->view('layout/footer');

    }
    public function detail($id){
        // akses model kategori peserta
        $this->load->model('kategoripeserta_model');
        $kategori_peserta = $this->kategoripeserta_model->getById($id);
        $data['kategori_peserta'] = $kategori_peserta;

         $this->load->view('layout/header');
         $this->load->view('layout/side');
         $this->load->view('kategori_peserta/detail', $data);
         $this->load->view('layout/footer');
     }
}
?>