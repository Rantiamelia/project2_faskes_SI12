<?php
class Jeniskegiatan extends CI_Controller{
    public function index(){
     // akses model

     $this->load->model('jeniskegiatan_model');
     $jenis_kegiatan = $this->jeniskegiatan_model->getAll();
     $data['jenis_kegiatan'] = $jenis_kegiatan;
        
        $this->load->view('layout/header');
        $this->load->view('layout/side');
        $this->load->view('jenis_kegiatan/index', $data);
        $this->load->view('layout/footer');

    }
    public function detail($id){
        // akses model jenis kegiatan
        $this->load->model('jeniskegiatan_model');
        $jenis_kegiatan = $this->jeniskegiatan_model->getById($id);
        $data['jenis_kegiatan'] = $jenis_kegiatan;

         $this->load->view('layout/header');
         $this->load->view('layout/side');
         $this->load->view('jenis_kegiatan/detail', $data);
         $this->load->view('layout/footer');
     }
}
?>