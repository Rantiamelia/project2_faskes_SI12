<?php
class Kategoripeserta_model extends CI_Model {
    public $nama;
    
    public function getAll(){
        // menampilkan seluruh data yang ada di tabel jenis kegiatan 
        $query =$this->db->get('kategori_peserta');
        return $query->result();
       }
    public function getById($id){
        // menampilkan data berdasarkan id
        $query = $this->db->get_where('kategori_peserta',['id' => $id]);
        return $query->row();
    }
   }
   
?>