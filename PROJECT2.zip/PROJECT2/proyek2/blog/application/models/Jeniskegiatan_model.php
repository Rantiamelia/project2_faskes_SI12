<?php
class Jeniskegiatan_model extends CI_Model {
    public $nama;

    public function getAll(){
        // menampilkan seluruh data yang ada di tabel jenis kegiatan 
        $query =$this->db->get('jenis_kegiatan');
        return $query->result();
       }
    
    public function getById($id){
        // menampilkan data berdasarkan id
        $query = $this->db->get_where('jenis_kegiatan',['id' => $id]);
        return $query->row();
    }
   }
   
?>